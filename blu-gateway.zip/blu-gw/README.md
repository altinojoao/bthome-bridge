# Gateway BLU

Transforma um telemóvel Android no gateway de um comando Shelly BLU, sem a
dongle USB e sem nenhum dispositivo Shelly por perto.

Funciona com a app fechada e o ecrã apagado: o scan é registado no subsistema
Bluetooth do Android através de um `PendingIntent`, e é o próprio sistema que
acorda a app quando o comando emite.

## Compilar sem instalar nada

1. Criar um repositório novo no GitHub (pode ser privado).
2. Carregar todos estes ficheiros, mantendo a estrutura de pastas.
3. Ir ao separador **Actions**. O workflow arranca sozinho no primeiro push.
4. Quando terminar, abrir a execução e descarregar o artefacto
   **blu-gateway-apk**.
5. Extrair o `.apk` e instalá-lo no telemóvel (é preciso autorizar a
   instalação de fontes desconhecidas).

O APK é de depuração e vem assinado com a chave de debug — chega para uso
pessoal, mas não serve para publicar na Play Store.

## Usar

1. Abrir a app e conceder as permissões pedidas.
2. **Detetar o comando** e carregar no botão durante a procura.
3. Escolher o comando na lista.
4. Preencher o endereço a chamar para os cliques que interessam.
5. **Começar a ouvir.**

Deixe em branco os cliques que não quer usar.

### Marcadores disponíveis no endereço

`{evento}` `{codigo}` `{botao}` `{mac}` `{bateria}` `{rssi}`

Em POST, se não indicar corpo, é enviado um JSON com todos estes campos.

## Antes de confiar nisto

Vá às definições de bateria do Android e ponha a app em **sem restrições**.
A Samsung e a Xiaomi matam processos em segundo plano de forma agressiva e é
esta a causa mais comum de cliques perdidos.

## Notas técnicas

O comando repete o mesmo anúncio cerca de vinte vezes por clique. A app
distingue um clique novo de um eco pelo ID de pacote BTHome (objeto `0x00`),
que se mantém constante durante as repetições e só muda no clique seguinte.
Esse último ID é guardado em disco, não em memória, porque o sistema mata e
reinicia o processo entre cliques.

O filtro de scan é obrigatório: o Android recusa scans por `PendingIntent` sem
pelo menos um `ScanFilter`. Aqui filtra-se pelo service data BTHome (`0xFCD2`)
e pelo endereço do comando.

Se o comando estiver emparelhado com encriptação, as tramas chegam ilegíveis e
o registo di-lo. Nesse caso é preciso desemparelhá-lo.
