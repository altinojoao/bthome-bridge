package pt.blugateway

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.os.ParcelUuid

/**
 * Nao e este servico que faz o scan: o scan e registado no proprio subsistema
 * Bluetooth e sobrevive-lhe. O servico existe para dar ao utilizador um
 * interruptor visivel e para reduzir a probabilidade de fabricantes agressivos
 * (Samsung, Xiaomi) matarem a app por completo.
 */
class ScanService : Service() {

    companion object {
        private const val CHANNEL = "escuta"
        private const val NOTIF_ID = 1
        private const val REQUEST = 4711

        fun start(context: Context) {
            val intent = Intent(context, ScanService::class.java)
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ScanService::class.java))
        }

        private fun scanPendingIntent(context: Context): PendingIntent {
            var flags = PendingIntent.FLAG_UPDATE_CURRENT
            if (Build.VERSION.SDK_INT >= 31) flags = flags or PendingIntent.FLAG_MUTABLE
            return PendingIntent.getBroadcast(
                context, REQUEST, Intent(context, ScanReceiver::class.java), flags
            )
        }

        /**
         * O filtro nao e opcional. O Android recusa scans por PendingIntent sem
         * pelo menos um ScanFilter, e e o filtro que evita acordar o processo a
         * cada anuncio que passa na rua.
         */
        @SuppressLint("MissingPermission")
        fun registerScan(context: Context): Boolean {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val scanner = manager?.adapter?.bluetoothLeScanner ?: return false

            val config = Config(context)
            val builder = ScanFilter.Builder()
                .setServiceData(ParcelUuid(BtHome.SERVICE_UUID), byteArrayOf(), byteArrayOf())
            config.mac?.let { builder.setDeviceAddress(it) }

            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
                .setReportDelay(0)
                .build()

            return try {
                scanner.startScan(listOf(builder.build()), settings, scanPendingIntent(context))
                true
            } catch (e: Exception) {
                Config(context).addLog("Nao foi possivel iniciar: ${e.message}")
                false
            }
        }

        @SuppressLint("MissingPermission")
        fun unregisterScan(context: Context) {
            val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
            val scanner = manager?.adapter?.bluetoothLeScanner ?: return
            try { scanner.stopScan(scanPendingIntent(context)) } catch (e: Exception) { /* ja parado */ }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIF_ID, buildNotification())
        registerScan(this)
        Config(this).running = true
        return START_STICKY
    }

    override fun onDestroy() {
        unregisterScan(this)
        Config(this).running = false
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL, "Escuta do comando", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Mostra que a app esta a ouvir o comando BLU." }
            (getSystemService(NotificationManager::class.java)).createNotificationChannel(channel)
        }

        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val name = Config(this).deviceName ?: "comando BLU"

        val builder = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, CHANNEL) else @Suppress("DEPRECATION") Notification.Builder(this)

        return builder
            .setContentTitle("A ouvir o $name")
            .setContentText("O clique funciona com o ecra apagado.")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }
}
