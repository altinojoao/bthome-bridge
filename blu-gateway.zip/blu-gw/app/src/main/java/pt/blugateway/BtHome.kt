package pt.blugateway

import java.util.UUID

/**
 * Descodificador BTHome v2 para dispositivos Shelly BLU.
 *
 * Trama tipica do BLU Button 1 (SBBT-002C), sete bytes:
 *
 *   40   00 23   01 64   3A 01
 *   |    |       |       |
 *   |    |       |       +-- objeto 0x3A: botao, valor 0x01 = clique simples
 *   |    |       +---------- objeto 0x01: bateria, 0x64 = 100 %
 *   |    +------------------ objeto 0x00: ID do pacote, 0x23 = 35
 *   +----------------------- cabecalho: bit 0 = encriptacao, bits 5-7 = versao
 *
 * O ID do pacote mantem-se igual em todas as repeticoes do mesmo clique e so
 * muda quando ha um clique novo. E por ai que se distingue um clique de um eco.
 */
object BtHome {

    val SERVICE_UUID: UUID = UUID.fromString("0000fcd2-0000-1000-8000-00805f9b34fb")

    /** Numero de bytes de cada objeto BTHome que nos interessa. */
    private val OBJECT_SIZES = mapOf(
        0x00 to 1, // ID do pacote
        0x01 to 1, // bateria %
        0x02 to 2, // temperatura
        0x03 to 2, // humidade
        0x05 to 3, // iluminancia
        0x0C to 2, // tensao
        0x0F to 1, // booleano generico
        0x11 to 1, // abertura
        0x15 to 1, // bateria fraca
        0x1A to 1, // porta
        0x20 to 1, // humidade binaria
        0x21 to 1, // movimento
        0x2D to 1, // janela
        0x2E to 1, // humidade
        0x2F to 1, // humidade do solo
        0x3A to 1, // botao
        0x3C to 2, // roda
        0x3F to 2, // rotacao
        0x45 to 2, // temperatura
        0x51 to 2  // aceleracao
    )

    val EVENT_NAMES = mapOf(
        1 to "Clique simples",
        2 to "Clique duplo",
        3 to "Clique triplo",
        4 to "Clique longo",
        5 to "Longo + duplo",
        6 to "Longo + triplo",
        0xFE to "A manter premido",
        0xFF to "Largado"
    )

    fun eventName(code: Int): String = EVENT_NAMES[code] ?: "Codigo $code"

    data class Frame(
        val version: Int,
        val encrypted: Boolean,
        val packetId: Int?,
        val battery: Int?,
        /** Um valor por cada objeto 0x3A encontrado, pela ordem em que aparece. */
        val buttons: List<Int>,
        val problem: String? = null
    ) {
        /** Cliques reais: o codigo 0 significa "sem evento" e e ignorado. */
        val presses: List<Pair<Int, Int>>
            get() = buttons.mapIndexed { i, code -> (i + 1) to code }.filter { it.second != 0 }
    }

    fun decode(data: ByteArray): Frame? {
        if (data.isEmpty()) return null

        val info = data[0].toInt() and 0xFF
        val version = info shr 5
        val encrypted = (info and 0x01) == 1

        if (encrypted) {
            return Frame(version, true, null, null, emptyList(),
                "Trama encriptada: e preciso a chave de emparelhamento.")
        }

        var i = 1
        var packetId: Int? = null
        var battery: Int? = null
        val buttons = mutableListOf<Int>()
        var problem: String? = null

        while (i < data.size) {
            val id = data[i].toInt() and 0xFF
            val len = OBJECT_SIZES[id]

            if (len == null) {
                problem = "Objeto desconhecido 0x%02X na posicao %d".format(id, i)
                break
            }
            if (i + 1 + len > data.size) {
                problem = "Trama truncada na posicao $i"
                break
            }

            // BTHome guarda os inteiros em little endian
            var value = 0
            for (k in len - 1 downTo 0) {
                value = (value shl 8) or (data[i + 1 + k].toInt() and 0xFF)
            }

            when (id) {
                0x00 -> packetId = value
                0x01 -> battery = value
                0x3A -> buttons.add(value)
            }

            i += 1 + len
        }

        return Frame(version, false, packetId, battery, buttons, problem)
    }
}
