package pt.blugateway

import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanResult
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.ParcelUuid
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Este receiver e a peca que torna a app diferente de uma pagina web: o
 * subsistema Bluetooth guarda o PendingIntent e acorda o processo quando
 * aparece um anuncio que passa o filtro, mesmo com a app fechada e o ecra
 * apagado.
 */
class ScanReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val results: List<ScanResult> = when {
            Build.VERSION.SDK_INT >= 33 ->
                intent.getParcelableArrayListExtra(
                    BluetoothLeScanner.EXTRA_LIST_SCAN_RESULT, ScanResult::class.java
                ) ?: emptyList()
            else -> @Suppress("DEPRECATION")
                (intent.getParcelableArrayListExtra(BluetoothLeScanner.EXTRA_LIST_SCAN_RESULT)
                    ?: emptyList<ScanResult>())
        }
        if (results.isEmpty()) return

        val config = Config(context)

        // O envio HTTP nao pode correr na thread do receiver, mas o processo
        // tambem nao pode morrer antes de terminar. goAsync() segura-o.
        val pending = goAsync()
        Thread {
            try {
                results.forEach { handle(context, config, it) }
            } finally {
                pending.finish()
            }
        }.start()
    }

    private fun handle(context: Context, config: Config, result: ScanResult) {
        val record = result.scanRecord ?: return
        val payload = record.serviceData?.get(ParcelUuid(BtHome.SERVICE_UUID)) ?: return

        val mac = result.device.address
        val target = config.mac
        if (target != null && !target.equals(mac, ignoreCase = true)) return

        val frame = BtHome.decode(payload) ?: return
        if (frame.encrypted) {
            config.addLog("${now()}  trama encriptada de $mac")
            return
        }
        if (frame.presses.isEmpty()) return

        // Aqui esta o que os testes mostraram ser essencial: sem isto, um
        // unico clique disparava o webhook vinte vezes seguidas.
        if (!config.isNewPress(mac, frame.packetId)) return

        frame.presses.forEach { (index, code) ->
            val label = BtHome.eventName(code)
            config.addLog("${now()}  $label  ${result.rssi} dBm")
            send(config, code, index, label, mac, frame.battery, result.rssi)
        }
    }

    private fun send(
        config: Config, code: Int, buttonIndex: Int, label: String,
        mac: String, battery: Int?, rssi: Int
    ) {
        val raw = config.url(code).trim()
        if (raw.isEmpty()) return

        val url = raw
            .replace("{evento}", enc(label))
            .replace("{codigo}", code.toString())
            .replace("{botao}", buttonIndex.toString())
            .replace("{mac}", enc(mac))
            .replace("{bateria}", (battery ?: "").toString())
            .replace("{rssi}", rssi.toString())

        var connection: HttpURLConnection? = null
        try {
            connection = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = config.method(code)
                connectTimeout = 8000
                readTimeout = 8000
                instanceFollowRedirects = true
            }

            if (connection.requestMethod == "POST") {
                val body = config.body(code).ifBlank {
                    """{"evento":"$label","codigo":$code,"botao":$buttonIndex,"mac":"$mac","bateria":${battery ?: "null"},"rssi":$rssi}"""
                }
                connection.doOutput = true
                connection.setRequestProperty(
                    "Content-Type",
                    if (body.trimStart().startsWith("{")) "application/json" else "text/plain"
                )
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body) }
            }

            val status = connection.responseCode
            config.addLog("${now()}  -> HTTP $status")
        } catch (e: Exception) {
            config.addLog("${now()}  -> falhou: ${e.message}")
        } finally {
            connection?.disconnect()
        }
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun now(): String =
        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
}

/** Retoma a escuta depois de o telemovel reiniciar, se estava ligada. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (!Config(context).running) return
        ScanService.start(context)
    }
}
