package pt.blugateway

import android.content.Context
import android.content.SharedPreferences

/**
 * Tudo o que a app precisa de recordar entre arranques.
 *
 * A deduplicacao vive aqui em vez de em memoria porque o processo e acordado
 * e morto varias vezes pelo sistema: o ultimo ID de pacote tem de sobreviver
 * a essas mortes, senao cada eco voltava a contar como clique novo.
 */
class Config(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("blu-gateway", Context.MODE_PRIVATE)

    companion object {
        const val KEY_MAC = "mac"
        const val KEY_NAME = "name"
        const val KEY_RUNNING = "running"
        /** Codigos de clique que a app deixa configurar. */
        val EVENTS = listOf(1, 2, 3, 4)
    }

    var mac: String?
        get() = prefs.getString(KEY_MAC, null)
        set(v) = prefs.edit().putString(KEY_MAC, v).apply()

    var deviceName: String?
        get() = prefs.getString(KEY_NAME, null)
        set(v) = prefs.edit().putString(KEY_NAME, v).apply()

    /** Se o utilizador deixou a escuta ligada, para a retomar depois do arranque. */
    var running: Boolean
        get() = prefs.getBoolean(KEY_RUNNING, false)
        set(v) = prefs.edit().putBoolean(KEY_RUNNING, v).apply()

    fun url(event: Int): String = prefs.getString("url_$event", "") ?: ""
    fun setUrl(event: Int, v: String) = prefs.edit().putString("url_$event", v).apply()

    fun method(event: Int): String = prefs.getString("method_$event", "GET") ?: "GET"
    fun setMethod(event: Int, v: String) = prefs.edit().putString("method_$event", v).apply()

    fun body(event: Int): String = prefs.getString("body_$event", "") ?: ""
    fun setBody(event: Int, v: String) = prefs.edit().putString("body_$event", v).apply()

    /**
     * Devolve true se este for um clique novo. Um eco do mesmo clique devolve false.
     * Tambem trata da rara reposicao do contador quando o comando troca de bateria.
     */
    fun isNewPress(mac: String, packetId: Int?): Boolean {
        if (packetId == null) return true // sem ID de pacote nao ha como deduplicar
        val key = "pid_$mac"
        val previous = prefs.getInt(key, -1)
        if (previous == packetId) return false
        prefs.edit().putInt(key, packetId).apply()
        return true
    }

    // --- registo curto, so para o utilizador ver o que aconteceu ---

    fun addLog(line: String) {
        val existing = prefs.getString("log", "") ?: ""
        val merged = (listOf(line) + existing.split("\n")).filter { it.isNotBlank() }.take(30)
        prefs.edit().putString("log", merged.joinToString("\n")).apply()
    }

    fun log(): String = prefs.getString("log", "") ?: ""

    fun clearLog() = prefs.edit().putString("log", "").apply()
}
