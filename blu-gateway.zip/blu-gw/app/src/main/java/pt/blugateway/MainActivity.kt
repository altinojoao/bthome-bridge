package pt.blugateway

import android.annotation.SuppressLint
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var config: Config
    private lateinit var status: TextView
    private lateinit var deviceLine: TextView
    private lateinit var logView: TextView
    private lateinit var toggle: Button

    private val urlFields = mutableMapOf<Int, EditText>()
    private val methodFields = mutableMapOf<Int, Spinner>()

    private val refresh = Handler(Looper.getMainLooper())
    private val refreshTask = object : Runnable {
        override fun run() {
            logView.text = config.log().ifBlank { "Ainda nao houve cliques." }
            refresh.postDelayed(this, 1500)
        }
    }

    private val askPermissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { granted ->
        if (granted.values.any { !it }) {
            Toast.makeText(this, "Sem estas permissoes a app nao consegue ouvir o comando.", Toast.LENGTH_LONG).show()
        }
        render()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        config = Config(this)
        setContentView(R.layout.activity_main)

        status = findViewById(R.id.status)
        deviceLine = findViewById(R.id.deviceLine)
        logView = findViewById(R.id.log)
        toggle = findViewById(R.id.toggle)

        buildEventRows()

        findViewById<Button>(R.id.detect).setOnClickListener { detectDevice() }
        findViewById<Button>(R.id.clearLog).setOnClickListener {
            config.clearLog(); logView.text = "Ainda nao houve cliques."
        }

        toggle.setOnClickListener {
            if (config.running) {
                ScanService.stop(this)
                config.running = false
            } else {
                if (!hasPermissions()) { requestPermissions(); return@setOnClickListener }
                if (config.mac == null) {
                    Toast.makeText(this, "Detete primeiro o comando.", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                ScanService.start(this)
            }
            Handler(Looper.getMainLooper()).postDelayed({ render() }, 400)
        }

        if (!hasPermissions()) requestPermissions()
    }

    override fun onResume() {
        super.onResume()
        render()
        refresh.post(refreshTask)
    }

    override fun onPause() {
        super.onPause()
        refresh.removeCallbacks(refreshTask)
        saveFields()
    }

    // ---------- permissoes ----------

    private fun neededPermissions(): List<String> {
        val list = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            list += android.Manifest.permission.BLUETOOTH_SCAN
            list += android.Manifest.permission.BLUETOOTH_CONNECT
        } else {
            list += android.Manifest.permission.ACCESS_FINE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33) list += android.Manifest.permission.POST_NOTIFICATIONS
        return list
    }

    private fun hasPermissions() = neededPermissions().all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestPermissions() = askPermissions.launch(neededPermissions().toTypedArray())

    // ---------- detecao do comando ----------

    @SuppressLint("MissingPermission")
    private fun detectDevice() {
        if (!hasPermissions()) { requestPermissions(); return }

        val manager = getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
        val scanner = manager?.adapter?.bluetoothLeScanner
        if (scanner == null) {
            Toast.makeText(this, "Ligue o Bluetooth do telemovel.", Toast.LENGTH_LONG).show()
            return
        }

        val found = linkedMapOf<String, String>()
        val dialog = AlertDialog.Builder(this)
            .setTitle("A procurar")
            .setMessage("Carregue no comando agora.\n\nSo aparecem aqui dispositivos que emitem BTHome.")
            .setNegativeButton("Cancelar", null)
            .create()
        dialog.show()

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val record = result.scanRecord ?: return
                record.serviceData?.get(ParcelUuid(BtHome.SERVICE_UUID)) ?: return
                val mac = result.device.address
                if (found.containsKey(mac)) return
                found[mac] = record.deviceName ?: result.device.name ?: "sem nome"
                dialog.setMessage(
                    "Encontrados:\n\n" + found.entries.joinToString("\n") { "${it.value}  ${it.key}" } +
                        "\n\nAguarde ou feche para escolher."
                )
            }
        }

        val filter = ScanFilter.Builder()
            .setServiceData(ParcelUuid(BtHome.SERVICE_UUID), byteArrayOf(), byteArrayOf())
            .build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()

        scanner.startScan(listOf(filter), settings, callback)

        Handler(Looper.getMainLooper()).postDelayed({
            try { scanner.stopScan(callback) } catch (e: Exception) { /* ja parado */ }
            dialog.dismiss()
            if (found.isEmpty()) {
                Toast.makeText(this, "Nao apareceu nada. Carregue no comando durante a procura.", Toast.LENGTH_LONG).show()
            } else {
                chooseDevice(found)
            }
        }, 12000)
    }

    private fun chooseDevice(found: Map<String, String>) {
        val macs = found.keys.toList()
        val labels = macs.map { "${found[it]}\n$it" }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Qual e o seu comando?")
            .setItems(labels) { _, which ->
                config.mac = macs[which]
                config.deviceName = found[macs[which]]
                if (config.running) { ScanService.stop(this); ScanService.start(this) }
                render()
            }
            .show()
    }

    // ---------- configuracao por tipo de clique ----------

    private fun buildEventRows() {
        val container = findViewById<LinearLayout>(R.id.events)
        val methods = arrayOf("GET", "POST")

        Config.EVENTS.forEach { code ->
            val row = layoutInflater.inflate(R.layout.row_event, container, false)

            row.findViewById<TextView>(R.id.eventName).text = BtHome.eventName(code)

            val url = row.findViewById<EditText>(R.id.url)
            url.setText(config.url(code))
            urlFields[code] = url

            val method = row.findViewById<Spinner>(R.id.method)
            method.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, methods)
            method.setSelection(methods.indexOf(config.method(code)).coerceAtLeast(0))
            methodFields[code] = method

            container.addView(row)
        }
    }

    private fun saveFields() {
        Config.EVENTS.forEach { code ->
            urlFields[code]?.let { config.setUrl(code, it.text.toString()) }
            methodFields[code]?.let { config.setMethod(code, it.selectedItem?.toString() ?: "GET") }
        }
    }

    // ---------- estado visivel ----------

    private fun render() {
        val on = config.running
        toggle.text = if (on) "Parar de ouvir" else "Comecar a ouvir"
        status.text = if (on) "A ouvir. Funciona com o ecra apagado." else "Parado."

        deviceLine.text = config.mac?.let { "${config.deviceName ?: "comando"}  ·  $it" }
            ?: "Nenhum comando escolhido."

        logView.text = config.log().ifBlank { "Ainda nao houve cliques." }
    }
}
